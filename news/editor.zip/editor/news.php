<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EditorMD</title>
    <link rel="stylesheet" type="text/css" href="plug-ins/EditorMD/lib/codemirror/codemirror.min.css" />
	<script type="text/javascript" src="plug-ins/JQuery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="plug-ins/EditorMD/editormd.min.js"></script>
	<link rel="stylesheet" type="text/css" href="plug-ins/EditorMD/css/editormd.css" />
</head>
<body>
    <div id="editormd">
        <textarea style="display:none;">### Hello Editor.md !</textarea>
    </div>
    <script type="text/javascript">
        $(function() {
            var editor = editormd("editormd", {
                width:"100%",
                height:"100%",
                path: 'plug-ins/EditorMD/lib/'
                });
            });
    </script>
    </script>
</body>
</html>